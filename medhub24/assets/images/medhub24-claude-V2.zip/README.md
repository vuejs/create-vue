# MedHub24 — Web App

Bilingual (English / Khmer) site for MedHub24's overseas medical treatment
coordination service. Static SPA, no build step.

## Structure

```
medhub24-webapp/
├── index.html
├── khmer-copy-tool.html      # internal Khmer copy editor
├── css/
│   ├── tailwind-shim.css     # ① replaces the removed Tailwind CDN
│   ├── styles.css            # ② existing layout (11k lines, preserved)
│   ├── medhub-theme.css      # ③ design system palette + components
│   └── medhub-type.css       # ④ typography authority — MUST LOAD LAST
├── js/
│   ├── config.js             # theme values + admin schema
│   ├── khmer-font.js         # verifies the Khmer webfont rendered
│   ├── i18n.js               # locale rendering + language storage
│   ├── khmer-copy-tool.js
│   └── app.js                # routing (navigateTo) + language toggle
├── locales/
│   ├── en/common.js
│   └── km/common.js          # APPROVED — production content
└── assets/
    ├── fonts/                # self-hosted Khmer faces + FONTS.md ← read this
    └── images/
```

Run: `python3 -m http.server 8000`. A server is required — `file://` blocks
the webfonts.

---

## Design system

The site follows the **Medhub24 design system**: Forest Teal `#2a635c` primary,
Mint `#6eca99` accent, Cream `#FAF7F2` ground, Sand `#D4A574` premium accent,
Coral `#E87968` for emphasis only, teal-tinted shadows, Angkor + Hanuman for
Khmer.

### What changed and why

`styles.css` had grown **five near-duplicate palettes** — home, checkup,
surgery, travel and accommodation each declared their own teal, mint, gold,
ivory and ink at slightly different values (`#0e756f` / `#0f6b72` / `#1b7b7a`
for "teal"; `#52d4ca` / `#63d0c7` / `#4fc8bd` for "mint"; four separate golds).
Same intent, five answers — which is what made the site read as assembled
rather than designed.

`css/medhub-theme.css` maps all five onto the design system by **redefining the
tokens the existing rules already read**, so the 11k lines of layout in
`styles.css` were not rewritten. Alongside it, 151 raw hex values and 232
near-black shadow tints were remapped in place.

Also normalised: one radius scale, one four-step teal-tinted shadow scale
(replacing ~90 bespoke shadows), consistent card and button treatments, and
one hover convention (`translateY(-1px)`, shadow step up).

**Primary CTAs are Forest Teal, not coral.** They were a coral→gold gradient on
every page; the design system reserves coral for emphasis "used sparingly", and
a permanent coral CTA reads promotional rather than clinical.

**To revert the whole theme:** remove the one `<link>` to `medhub-theme.css`
in `index.html`. The palette remap inside `styles.css` is not reverted by that,
so keep a branch if you need a clean rollback.

---

## Typography

English and Khmer are separated **structurally**, not by convention:

1. **`unicode-range`.** The Khmer faces are declared for Khmer codepoints only.
   A Latin glyph cannot resolve to a Khmer face and vice versa.
2. **`html[lang]` scoping.** Khmer metrics live under `html[lang="km"]`,
   English under `html[lang="en"]`. Editing one cannot move the other.

| Script | Role | Family |
|---|---|---|
| Khmer | body, UI, headings | **Hanuman** (self-hosted) |
| Khmer | hero headlines | **Angkor** (self-hosted) |
| Latin | body | Plus Jakarta Sans |
| Latin | headings | Poppins |

Both Khmer faces are self-hosted, so Khmer cannot be replaced by a device font
and does not depend on a CDN. `js/khmer-font.js` verifies this on every load
and writes `data-khmer-font="selfhosted"` or `"fallback"` to `<html>`.
See `assets/fonts/FONTS.md`.

### Rules for editing Khmer type

- Sizes come from the `--medhub-km-*` token scale at the top of
  `medhub-type.css`. Never write a literal Khmer font-size.
- **Khmer is never smaller than the Latin it replaces.** `styles.css` contained
  eight hand-tuned header rules doing the opposite (nav labels at 11.5px, brand
  subtitle at 10.2px) to force the nav onto one row. All now read the tokens;
  the nav row scrolls instead.
- Never use negative `letter-spacing` on Khmer — it collides the subscript
  consonants (coeng) with their base.
- Never use `word-break: break-all`, `overflow-wrap: anywhere` or
  `line-break: anywhere` on Khmer — they split a consonant from its own vowel
  sign mid-cluster. Use `overflow-wrap: break-word` with `line-break: auto`.
- Never apply `text-transform: uppercase` or wide tracking to Khmer.
- Khmer needs ~0.25–0.3 more line-height than Latin at the same size.
- Khmer has no italic; `<em>` renders as emphasis, not a slant.
- Hanuman has one weight. Hierarchy comes from size and colour, not weight.

---

## Content

Both languages are keyed dictionaries in `locales/`. **Never hard-code
translated copy in `index.html`** — add a key and a `data-i18n` attribute.

`locales/km/common.js` is the approved production content. The English file
carries the same meaning, medical context and business message; if the Khmer
changes, update the matching English key.

Khmer punctuation (`?`, `។`, `៖`, `ៗ`) is preceded by a non-breaking space so
it can never orphan onto its own line. Preserve those when editing.

### 76 keys are defined but never displayed

Pre-existing. Both locales carry two parallel sets of copy for several
sections — a detailed original and a shorter set the markup actually uses. The
travel cards render `travel.story.beforeFlight` while
`travel.story.card1.title` and its longer `.desc` sit unused.

Harmless at runtime, but it means **some approved Khmer copy is not visible on
the site**. Worth a content review — either wire the richer strings in, or
delete them. To list them:

```js
const used = new Set([...document.querySelectorAll('[data-i18n]')].map(e => e.dataset.i18n));
Object.keys(MEDHUB_LOCALES.en).filter(k => !used.has(k) && !k.startsWith('meta.'));
```

---

## Notes

- The Tailwind CDN was removed; `css/tailwind-shim.css` implements only the
  utilities `index.html` uses. New Tailwind class names in the markup will not
  work until added there (or you move to a real Tailwind build).
- The manager portrait is still hot-linked from a signed `chatglm.cn` URL whose
  `auth_key` expires. It now degrades to a monogram rather than a broken image,
  but download it into `assets/images/` before production.
- Phone: displayed `012 464 639` / `+855 12 464 639`, linked `tel:+85512464639`.
  **Please confirm** — the brief gave `(+8551)2464639`, which does not parse as
  a Cambodian mobile number.
- Facebook blue `#1877f2` is deliberately kept off-palette on the social link.
